package com.coderbd.noticeboard;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class LoginAll extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_all);
    }
}
